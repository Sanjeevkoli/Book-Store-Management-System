package com.sprint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
