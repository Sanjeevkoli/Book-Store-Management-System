package com.sprint.bookstore.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sprint.bookstore.entities.Address;
import com.sprint.bookstore.entities.BookOrder;
import com.sprint.bookstore.entities.Customer;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class BookOrderServiceImplTest {

	@Autowired
	private BookOrderServiceImpl bookOrderService;
	@Test
	public final void testAddOrder() {
		BookOrder bookOrder = new BookOrder();
		Customer customer = new Customer();
		Address address = new Address(); 
		
		bookOrder.setOrderId(1);
		bookOrder.setOrderDate("1999-02-12");
		bookOrder.setOrderTotal(20);
		bookOrder.setPaymentMethod("upi");
		bookOrder.setRecipientName("sk");
		bookOrder.setRecipientPhone("1236547896");
		bookOrder.setStatus("done");
		
		customer.setCustomerId(8);
		customer.setFullName("ysh");
		customer.setMobileNumber("1236547896");
		customer.setRegisterOn("2000-08-06");
		
		address.setAddressId(4);
		 address.setAddress("prajwal"); 
		 address.setCity("Kopl"); 
		 address.setCountry("India");
		 address.setPincode("427422"); 
		 customer.setAddress(address);
		bookOrder=bookOrderService.addOrder(bookOrder);
		assertThat(bookOrder.getRecipientName().equalsIgnoreCase("sk"));
	}

	@Test
	public final void testUpdateOrder() {
		BookOrder bookOrder = new BookOrder();
		Customer customer = new Customer();
		Address address = new Address(); 
		
		bookOrder.setOrderId(1);
		bookOrder.setOrderDate("1999-02-12");
		bookOrder.setOrderTotal(20);
		bookOrder.setPaymentMethod("upi");
		bookOrder.setRecipientName("skk");
		bookOrder.setRecipientPhone("1236547896");
		bookOrder.setStatus("done");
		customer.setCustomerId(8);
		customer.setFullName("ysh");
		customer.setMobileNumber("1236547896");
		customer.setRegisterOn("2000-08-06");
		
		address.setAddressId(4);
		 address.setAddress("prajwal"); 
		 address.setCity("Kopl"); 
		 address.setCountry("India");
		 address.setPincode("427422"); 
		 customer.setAddress(address);
		bookOrder=bookOrderService.addOrder(bookOrder);
		assertThat(bookOrder.getRecipientName().equalsIgnoreCase("skk"));
	}

	@Test
	public final void testRemoveOrder() {
		BookOrder bookOrder = new BookOrder();
		Customer customer = new Customer();
		Address address = new Address();
		
		bookOrder.setOrderId(1);
		bookOrder.setOrderDate("1999-02-12");
		bookOrder.setOrderTotal(20);
		bookOrder.setPaymentMethod("upi");
		bookOrder.setRecipientName("sk");
		bookOrder.setRecipientPhone("1236547896");
		bookOrder.setStatus("done");
		customer.setCustomerId(8);
		customer.setFullName("ysh");
		customer.setMobileNumber("1236547896");
		customer.setRegisterOn("2000-08-06");
		
		address.setAddressId(4);
		 address.setAddress("prajwal"); 
		 address.setCity("Kopl"); 
		 address.setCountry("India");
		 address.setPincode("427422"); 
		 customer.setAddress(address);
		bookOrder=bookOrderService.addOrder(bookOrder);
		bookOrderService.removeOrder(bookOrder);
		assertThat(bookOrder.getOrderId()==0);
	}

	@Test
	public final void testViewAll() {
		List<BookOrder> bookOrders = bookOrderService.viewAll();
		assertThat(bookOrders.size()>0);
	}

}
