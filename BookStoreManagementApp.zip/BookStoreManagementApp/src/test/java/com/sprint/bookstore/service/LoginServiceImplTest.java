package com.sprint.bookstore.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sprint.bookstore.entities.User;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class LoginServiceImplTest {

	@Autowired
	private LoginServiceImpl loginService;
	@Test
	public final void testAddUser() {
		User user = new User();
		user.setUserId(6);
		user.setEmail("poc@gmail");
		user.setPassword("45632163");
		user= loginService.addUser(user);
		assertThat(user.getEmail().equalsIgnoreCase("poc@gmail"));
	}

	@Test
	public final void testRemoveUser() {
		User user = new User();
		user.setUserId(40);
		user.setEmail("poc@gmail");
		user.setPassword("45632163");
		user= loginService.addUser(user);
		loginService.removeUser(user);
		assertThat(user.getUserId()==0);
	}

}
