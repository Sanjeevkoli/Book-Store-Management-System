package com.sprint.bookstore.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sprint.bookstore.entities.Address;
import com.sprint.bookstore.service.AddressServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class AddressServiceImplTest {
	@Autowired
	private AddressServiceImpl addressService;

	@Test
	public final void testAddAddress() {
		Address address=new Address();
		address.setAddressId(8);
		address.setAddress("abc");
		address.setCity("Kop");
		address.setCountry("Ind");
		address.setPincode("123654");
		address=addressService.addAddress(address);
		assertThat(address.getAddress().equalsIgnoreCase("abc"));
	}

	@Test
	public final void testUpdateAddress() {
		Address address=new Address();
		address.setAddressId(5);
		address.setAddress("abcdf");
		address.setCity("Kolhpur");
		address.setCountry("India");
		address.setPincode("412578");
		address=addressService.updateAddress(address);
		assertThat(address.getAddress().equalsIgnoreCase("abcdf"));
	}

	@Test
	public final void testRemoveAddress() {
		Address address = new Address();
		address.setAddressId(8);
		address.setAddress("abc");
		address.setCity("Kop");
		address.setCountry("Ind");
		address.setPincode("123654");
		address=addressService.addAddress(address);
		addressService.removeAddress(address);
		assertThat(address.getAddressId()==0);
	}

	@Test
	public final void testViewAllAddress() {
		List<Address> addresses = addressService.viewAllAddress();
		assertThat(addresses.size()>0);
	}

	@Test
	public final void testViewAddress() {
		Address address = new Address();
		assertThat(address.getAddressId()==1);
	}

}
