package com.sprint.bookstore.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sprint.bookstore.entities.Book;
import com.sprint.bookstore.entities.Category;
import com.sprint.bookstore.entities.OrderDetails;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class OrderDetailsServiceImplTest {

	@Autowired
	private OrderDetailsServiceImpl orderDetailsService;
	@Test
	public final void testAddOrderDetails() {
		OrderDetails orderDetails = new OrderDetails();
		Book book = new Book();
		Category cat= new Category();
		book.setBookId(1);
		book.setTitle("askk");
		book.setAuthor("skd");
		book.setDescription("dlo");
		book.setIsbn("1234");
		book.setPrice(20);
		book.setPublishDate("2000-09-08");
		book.setLastUpdatedOn("2001-09-08");
		
		cat.setCategoryId(1);
		cat.setCategoryName("lka");
		orderDetails.setOrderDetailsId(1);
		orderDetails.setQuantity(5);
		orderDetails.setSubtotal(25);
		orderDetails=orderDetailsService.addOrderDetails(orderDetails);
		assertThat(orderDetails.getQuantity()==5);
	}

	@Ignore
	public final void testUpdateOrderDetails() {
		OrderDetails orderDetails = new OrderDetails();
		Book book = new Book();
		Category cat= new Category();
		book.setBookId(1);
		book.setTitle("askk");
		book.setAuthor("skd");
		book.setDescription("dlo");
		book.setIsbn("1234");
		book.setPrice(20);
		book.setPublishDate("2000-09-08");
		book.setLastUpdatedOn("2001-09-08");
		
		cat.setCategoryId(1);
		cat.setCategoryName("lka");
		orderDetails.setOrderDetailsId(1);
		orderDetails.setQuantity(10);
		orderDetails.setSubtotal(25);
		orderDetails=orderDetailsService.updateOrderDetails(orderDetails);
		assertThat(orderDetails.getQuantity()==10);
	}

	@Test
	public final void testRemoveOrderDetails() {
		OrderDetails orderDetails = new OrderDetails();
		Book book = new Book();
		Category cat= new Category();
		book.setBookId(1);
		book.setTitle("askk");
		book.setAuthor("skd");
		book.setDescription("dlo");
		book.setIsbn("1234");
		book.setPrice(20);
		book.setPublishDate("2000-09-08");
		book.setLastUpdatedOn("2001-09-08");
		
		cat.setCategoryId(1);
		cat.setCategoryName("lka");
		
		orderDetails.setOrderDetailsId(2);
		orderDetails.setQuantity(15);
		orderDetails.setSubtotal(25);
		orderDetails=orderDetailsService.addOrderDetails(orderDetails);
		orderDetails=orderDetailsService.removeOrderDetails(orderDetails);
		assertThat(orderDetails.getOrderDetailsId()==0);
	}

	@Test
	public final void testViewAll() {
		List<OrderDetails> orderDetails = orderDetailsService.viewAll();
		assertThat(orderDetails.size()>0);
	}

}
