package com.sprint.bookstore.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sprint.bookstore.entities.Address;
import com.sprint.bookstore.entities.Category;
import com.sprint.bookstore.service.CategoryServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class CategoryServiceImplTest {

	@Autowired
	private CategoryServiceImpl categoryService;
	@Test
	public final void testAddCategory() {
		Category category= new Category();
		category.setCategoryId(9);
		category.setCategoryName("jkl");
		category= categoryService.addCategory(category);
		assertThat(category.getCategoryName().equalsIgnoreCase("jkl"));
	}

	@Test
	public final void testEditCategory() {
		Category category= new Category();
		category.setCategoryId(9);
		category.setCategoryName("jhl");
		category= categoryService.editCategory(category);
		assertThat(category.getCategoryName().equalsIgnoreCase("jhl"));
	}

	@Test
	public final void testViewAllCategories() {
		List<Category> categories = categoryService.viewAllCategories();
		assertThat(categories.size()>0);
	}

	@Test
	public final void testRemoveCategory() {
		Category category= new Category();
		category.setCategoryId(2);
		category.setCategoryName("jhl");
		category= categoryService.addCategory(category);
		categoryService.removeCategory(category);
		assertThat(category.getCategoryId()==0);
	}

}
