package com.sprint.bookstore.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sprint.bookstore.entities.Address;
import com.sprint.bookstore.entities.Customer;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class CustomerServiceImplTest {

	@Autowired
	private CustomerServiceImpl customerService;
	@Test
	public final void testCreateCustomer() {
		Customer customer = new Customer();
		Address address = new Address(); 
		customer.setCustomerId(8);
		customer.setFullName("ysh");
		customer.setMobileNumber("1236547896");
		customer.setRegisterOn("2000-08-06");
		
		  
		  address.setAddressId(4);
		 address.setAddress("prajwal"); 
		 address.setCity("Kopl"); 
		 address.setCountry("India");
		 address.setPincode("427422"); 
		 customer.setAddress(address);
		 
		
		customer=customerService.createCustomer(customer);
		assertThat(customer.getFullName().equalsIgnoreCase("ysh"));
	}

	@Test
	public final void testListCustomers() {
		List<Customer> customers = customerService.listCustomers();
		assertThat(customers.size()>0);
	}

	@Test
	public final void testDeleteCustomer() {
		Customer customer = new Customer();
		Address address = new Address(); 
		customer.setCustomerId(8);
		customer.setFullName("ysh");
		customer.setMobileNumber("1236547896");
		customer.setRegisterOn("2000-08-06");
		
		  
		  address.setAddressId(4);
		 address.setAddress("prajwal"); 
		 address.setCity("Kopl"); 
		 address.setCountry("India");
		 address.setPincode("427422"); 
		 customer.setAddress(address);
		customerService.deleteCustomer(customer);
		assertThat(customer.getCustomerId()==0);
	}

	@Test
	public final void testUpdateCustomer() {
		Customer customer = new Customer();
		Address address = new Address(); 
		customer.setCustomerId(8);
		customer.setFullName("ash");
		customer.setMobileNumber("1236547896");
		customer.setRegisterOn("2000-08-06");
		
		  
		  address.setAddressId(4);
		 address.setAddress("prajwal"); 
		 address.setCity("Kopl"); 
		 address.setCountry("India");
		 address.setPincode("427422"); 
		 customer.setAddress(address);
		customer=customerService.updateCustomer(customer);
		assertThat(customer.getFullName().equalsIgnoreCase("ash"));
	}
}
