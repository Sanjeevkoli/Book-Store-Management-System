package com.sprint.bookstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bookId; // primary
	@NotEmpty(message = "title Name is required")
	@Pattern(regexp = "^[a-zA-Z]*$", message = "Accepts Alphabets Only! Enter Valid Name")
	private String title;
	@NotEmpty(message = "author Name is required")
	private String author;
	@OneToOne
	@JoinColumn(name = "categoryId")
	private Category category;
	@NotEmpty(message = "description Name is required")
	private String description;
	@NotEmpty(message = "isbn Name is required")
	@Pattern(regexp = "^\\d{4}$", message = "Accepts Numbers Only! Enter Valid Number")
	private String isbn;
	private float price;
	private String publishDate;
	private String lastUpdatedOn;

	public Book() {
		super();
	}

	public Book(int bookId, String title, String author, Category category, String description, String isbn,
			float price, String publishDate, String lastUpdatedOn) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.category = category;
		this.description = description;
		this.isbn = isbn;
		this.price = price;
		this.publishDate = publishDate;
		this.lastUpdatedOn = lastUpdatedOn;
	}

	@Column(name = "BookId", length = 10)
	
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	@Column(name = "Title", length = 10)
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name = "Author", length = 10)
	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Column(name = "Description", length = 10)
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name = "Isbn", length = 10)
	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	@Column(name = "Price", length = 10)
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Column(name = "PublishedDate", length = 10)
	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

	@Column(name = "LastUpdatedOn", length = 10)
	public String getLastUpdatedOn() {
		return lastUpdatedOn;
	}

	public void setLastUpdatedOn(String lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + ", category=" + category
				+ ", description=" + description + ", isbn=" + isbn + ", price=" + price + ", publishDate="
				+ publishDate + ", lastUpdatedOn=" + lastUpdatedOn + "]";
	}

}
