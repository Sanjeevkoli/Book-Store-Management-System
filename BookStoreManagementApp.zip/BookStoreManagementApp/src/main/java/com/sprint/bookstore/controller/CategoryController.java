package com.sprint.bookstore.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.bookstore.entities.Category;
import com.sprint.bookstore.exception.CategoryNotFoundException;
import com.sprint.bookstore.service.ICategoryService;

@RestController
@RequestMapping("/api")
public class CategoryController {

	@Autowired
	private ICategoryService categoryService;

	//Adding category in database
		@PostMapping("/category/newcategory")
		public Category addCategory(@Valid @RequestBody Category cat)
		{
			return categoryService.addCategory(cat);
		}
		
	// Retrieves specific Category from db
	@GetMapping("/ category/id/{id}")
	public ResponseEntity<Category> getCategoryById(@PathVariable(value = "id") int categoryId)
			throws CategoryNotFoundException {
		Category category = categoryService.getCategoryById(categoryId)
				.orElseThrow(() -> new CategoryNotFoundException("No Category  found with this id: " + categoryId));
		return ResponseEntity.ok().body(category);
	}

	// Retrieves all Category from db
	@GetMapping("/Categories/all")
	public List<Category> getAllCategory() {
		return categoryService.viewAllCategories();
	}

	// Updates existingCategorydetails using provided Category id
	@PutMapping("/Categories/update/{id}")
	public ResponseEntity<Category> updateCategoryById(@PathVariable(value = "id") Integer categoryId,@Valid @RequestBody Category updCategory) throws CategoryNotFoundException {
		Category category = categoryService.getCategoryById(categoryId).orElseThrow(() -> new CategoryNotFoundException("No Category found with this id: " + categoryId));
		category.setCategoryName(updCategory.getCategoryName());
		Category editedCategory = categoryService.editCategory(category);
		return ResponseEntity.ok(editedCategory);

	}

	// Deletes an Category record usingCategory id
	@DeleteMapping("/Categories/delete/{id}")
	public Map<String, Boolean> deleteCategory(@PathVariable(value = "id") Integer CategoryId)
			throws CategoryNotFoundException {
		Category category = categoryService.getCategoryById(CategoryId)
				.orElseThrow(() -> new CategoryNotFoundException("No Categoryfound with this id: " + CategoryId));
		categoryService.removeCategory(category);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return response;
	}

	// Displays messages assigned as per Validation Constraints
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		// Key being the fieldname and message being the values/message associated
		Map<String, String> errors = new HashMap<>();

		// gets messages (assigned) for all individual fields
		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));

		return errors;

	}

}