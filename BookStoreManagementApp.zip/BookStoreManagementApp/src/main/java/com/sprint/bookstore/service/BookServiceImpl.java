package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.bookstore.entities.Book;
import com.sprint.bookstore.repository.IBookRepository;

@Service
public class BookServiceImpl implements IBookService {

	@Autowired
	private IBookRepository iBookRepository;

	@Override
	public Book createBook(Book b) {

		return iBookRepository.save(b);
	}

	@Override
	public List<Book> listAllBooks() {

		return iBookRepository.findAll();
	}

	@Override
	public Book deleteBook(Book b) {

		iBookRepository.delete(b);
		return b;
	}

	@Override
	public Book editBook(Book b) {
		return iBookRepository.save(b);
	}

	@Override
	public Optional<Book> getBookById(Integer bookId) {
		// TODO Auto-generated method stub
		return iBookRepository.findById(bookId);
	}

}
