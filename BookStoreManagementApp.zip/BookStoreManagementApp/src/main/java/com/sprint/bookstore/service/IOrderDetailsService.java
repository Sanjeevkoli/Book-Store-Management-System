package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import com.sprint.bookstore.entities.OrderDetails;

public interface IOrderDetailsService {

	public OrderDetails addOrderDetails(OrderDetails orderDetails);

	public OrderDetails updateOrderDetails(OrderDetails orderDetails);

	public OrderDetails removeOrderDetails(OrderDetails orderDetails);

	public List<OrderDetails> viewAll();

	Optional<OrderDetails> findByOrderDetails(int orderDetailsId);
}
