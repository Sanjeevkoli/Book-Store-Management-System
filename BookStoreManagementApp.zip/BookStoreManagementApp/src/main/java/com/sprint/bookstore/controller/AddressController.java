package com.sprint.bookstore.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.bookstore.entities.Address;
import com.sprint.bookstore.exception.AddressNotFoundException;
import com.sprint.bookstore.service.IAddressService;

@RestController
@RequestMapping("/api")
public class AddressController {

	@Autowired
	private IAddressService addressService;

	// Adding address in database
	@PostMapping("/address/newaddress")
	public Address addAddress(@Valid @RequestBody Address add) {
		return addressService.addAddress(add);
	}

	// Update address in database
	@PutMapping("/address/update/{addressId}")
	public ResponseEntity<Address> updateAddressById(@PathVariable(value = "addressId") Integer addressId,
			@RequestBody Address updadd) throws AddressNotFoundException {
		Address add = addressService.viewAddress(addressId)
				.orElseThrow(() -> new AddressNotFoundException("No address found with gives addressId:" + addressId));
		add.setAddress(updadd.getAddress());
		add.setCity(updadd.getCity());
		add.setCountry(updadd.getCountry());
		add.setPincode(updadd.getPincode());

		Address updatedAddress = addressService.updateAddress(add);
		return ResponseEntity.ok(updatedAddress);

	}

	// Delete Address by using address ID
	@DeleteMapping("/address/delete/{addressId}")
	public ResponseEntity<Address> removeAddress(@PathVariable("addressId") Integer addressId)
			throws AddressNotFoundException {
		Address add = addressService.viewAddress(addressId)
				.orElseThrow(() -> new AddressNotFoundException("Address not Found with this id: " + addressId));
		addressService.removeAddress(add);

		return ResponseEntity.ok(null);
	}

	// View All addresses from database
	@GetMapping("/address/viewall")
	public List<Address> ViewAllAddress() {
		return addressService.viewAllAddress();
	}

	// View Address using address ID
	@GetMapping("/address/view/{addressId}")
	public ResponseEntity<Address> viewAddress(@PathVariable(value = "addressId") Integer addressId)
			throws AddressNotFoundException {
		Address add = addressService.viewAddress(addressId)
				.orElseThrow(() -> new AddressNotFoundException("No address found with given addressId: " + addressId));
		return ResponseEntity.ok().body(add);
	}

	// Display messages assigned as per Validation Constraints
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();

		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));

		return errors;

	}

}
