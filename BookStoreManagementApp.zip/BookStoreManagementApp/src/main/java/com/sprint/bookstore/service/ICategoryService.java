package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import com.sprint.bookstore.entities.Category;

public interface ICategoryService {

	public Category addCategory(Category cat);
	public Category editCategory(Category cat);
	public List<Category> viewAllCategories();
	public Optional<Category> getCategoryById(Integer categoryId);
	public Category removeCategory(Category cat);
}