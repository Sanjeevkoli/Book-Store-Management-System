package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.bookstore.entities.OrderDetails;
import com.sprint.bookstore.repository.IOrderDetailsRepository;

@Service
public class OrderDetailsServiceImpl implements IOrderDetailsService {

	@Autowired
	private IOrderDetailsRepository iorderDetailsRepository;

	@Override
	public OrderDetails addOrderDetails(OrderDetails orderDetails) {
		return iorderDetailsRepository.save(orderDetails);
	}

	@Override
	public OrderDetails updateOrderDetails(OrderDetails orderDetails) {

		return iorderDetailsRepository.save(null);
	}

	@Override
	public OrderDetails removeOrderDetails(OrderDetails orderDetails) {
		iorderDetailsRepository.delete(orderDetails);
		return orderDetails;
	}

	@Override
	public List<OrderDetails> viewAll() {

		return iorderDetailsRepository.findAll();
	}

	@Override
	public Optional<OrderDetails> findByOrderDetails(int orderDetailsId) {

		return iorderDetailsRepository.findById(orderDetailsId);
	}

}
