package com.sprint.bookstore.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.bookstore.entities.Customer;
import com.sprint.bookstore.exception.CustomerNotFoundException;
import com.sprint.bookstore.service.ICustomerService;

@RestController
@RequestMapping("/api")
public class CutomerController {

	@Autowired
	private ICustomerService customerService;

	// Inserts new customer in db
	@PostMapping("/customers/newcust")
	public Customer createCustomer(@Valid @RequestBody Customer customer) {
		return customerService.createCustomer(customer);
	}

	// Retrieves all customers from db
	@GetMapping("/cutomers/all")
	public List<Customer> listCustomers() {
		return customerService.listCustomers();
	}

	// Retrieves specific customer from db
	@GetMapping("customers/id/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable(value = "id") Integer customerId)
			throws CustomerNotFoundException {
		Customer customer = customerService.getCustomerById(customerId)
				.orElseThrow(() -> new CustomerNotFoundException("No customer found with this id: " + customerId));
		return ResponseEntity.ok().body(customer);
	}

	// Updates existing customer details using provided customer id
	@PutMapping("/customers/update/{id}")
	public ResponseEntity<Customer> updateCustomerById(@PathVariable(value = "id") Integer customerId,
			@Valid @RequestBody Customer updcust) throws CustomerNotFoundException {
		Customer customer = customerService.getCustomerById(customerId)
				.orElseThrow(() -> new CustomerNotFoundException("No cutomer found with this id: " + customerId));
		customer.setFullName(updcust.getFullName());
		customer.setAddress(updcust.getAddress());
		customer.setMobileNumber(updcust.getMobileNumber());
		customer.setRegisterOn(updcust.getRegisterOn());
		customer.setCustomerId(customerId);
		Customer updatedCustomer = customerService.updateCustomer(customer);
		return ResponseEntity.ok(updatedCustomer);
	}

	// Deletes an employee record using employee id
	@DeleteMapping("/customers/delete/{id}")
	public Map<String, Boolean> deleteCustomer(@PathVariable(value = "id") Integer customerId)
			throws CustomerNotFoundException {
		Customer customer = customerService.getCustomerById(customerId)
				.orElseThrow(() -> new CustomerNotFoundException("No customer found with this id: " + customerId));
		customerService.deleteCustomer(customer);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return response;
	}

	// get cart
	@GetMapping("/customer/id/{id}")
	public ResponseEntity<Customer> viewCart(@PathVariable(value = "id") Integer customerId)
			throws CustomerNotFoundException {
		Customer customer = customerService.viewCustomer(customerId)
				.orElseThrow(() -> new CustomerNotFoundException("No cart found with this id: " + customerId));
		return ResponseEntity.ok().body(customer);
	}

	// Displays messages assigned as per Validation Constraints
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		// Key being the fieldname and message being the values/message associated
		Map<String, String> errors = new HashMap<>();

		// gets messages (assigned) for all individual fields
		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));

		return errors;
	}
}
