package com.sprint.bookstore.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "review1")
public class Review {

	@Id
	private int reviewId; // primary
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "bookId")
	private Book book;
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "customerId")
	private Customer customer;
	@NotEmpty(message = "headLine Name is required")
	private String headLine;
	@NotEmpty(message = "comment Name is required")
	private String commnt;
	private double rating;
	private String reviewOn;

	public Review() {
		super();
	}

	public Review(Book book, Customer customer, String headLine, String comment, double rating, String reviewOn) {
		super();
		this.book = book;
		this.customer = customer;
		this.headLine = headLine;
		this.commnt = commnt;
		this.rating = rating;
		this.reviewOn = reviewOn;
	}

	@Column(name = "ReviewId", length = 10)
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getReviewId() {
		return reviewId;
	}

	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Column(name = "HeadLine", length = 10)
	public String getHeadLine() {
		return headLine;
	}

	public void setHeadLine(String headLine) {
		this.headLine = headLine;
	}

	@Column(name = "Comment", length = 10)
	public String getComment() {
		return commnt;
	}

	public void setComment(String commnt) {
		this.commnt = commnt;
	}

	@Column(name = "Rating", length = 10)
	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	@Column(name = "ReviewOn", length = 10)
	public String getReviewOn() {
		return reviewOn;
	}

	public void setReviewOn(String reviewOn) {
		this.reviewOn = reviewOn;
	}

	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", book=" + book + ", customer=" + customer + ", headLine=" + headLine
				+ ", comment=" + commnt + ", rating=" + rating + ", reviewOn=" + reviewOn + "]";
	}

}
