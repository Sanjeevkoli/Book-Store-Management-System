package com.sprint.bookstore.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.bookstore.entities.OrderDetails;
import com.sprint.bookstore.exception.OrderDetailsNotFoundException;
import com.sprint.bookstore.service.IOrderDetailsService;

@RestController
@RequestMapping("/api")
public class OrderDetailsController {

	@Autowired
	private IOrderDetailsService orderDetailsService;

	// Adding OrderDetails in database
	@PostMapping("/orderdetails/neworderdetails")
	public OrderDetails addOrderDetails(@Valid @RequestBody OrderDetails orderDetails) {
		return orderDetailsService.addOrderDetails(orderDetails);
	}

	// Update OrderDetails in database
	@PutMapping("/orderdetails/update/{orderDetailsId}")
	public ResponseEntity<OrderDetails> updateAddressById(
			@PathVariable(value = "orderDetailsId") Integer orderDetailsId, @RequestBody OrderDetails upddetl)
			throws OrderDetailsNotFoundException {
		OrderDetails orderdetails = orderDetailsService.findByOrderDetails(orderDetailsId)
				.orElseThrow(() -> new OrderDetailsNotFoundException(
						"No OrderDetail found with gives orderDetailsId:" + orderDetailsId));
		orderdetails.setBook(upddetl.getBook());
		orderdetails.setQuantity(upddetl.getQuantity());
		orderdetails.setSubtotal(upddetl.getSubtotal());

		OrderDetails updatedOrderDetails = orderDetailsService.updateOrderDetails(orderdetails);
		return ResponseEntity.ok(updatedOrderDetails);

	}

	// Delete OrderDetails by using OrderDetails ID
	@DeleteMapping("/orderdetails/delete/{orderDetailsId}")
	public ResponseEntity<OrderDetails> removeOrderDetails(@PathVariable("orderDetailsId") Integer orderDetailsId)
			throws OrderDetailsNotFoundException {
		OrderDetails orderdetails = orderDetailsService.findByOrderDetails(orderDetailsId).orElseThrow(
				() -> new OrderDetailsNotFoundException("OrderDetail not Found with this id: " + orderDetailsId));
		orderDetailsService.removeOrderDetails(orderdetails);

		return ResponseEntity.ok(null);
	}

	// View All OrderDetails from database
	@GetMapping("/orderdetails/viewall")
	public List<OrderDetails> ViewAll() {
		return orderDetailsService.viewAll();
	}

	// View Address using address ID
	@GetMapping("/orderdetails/view/{addressId}")
	public ResponseEntity<OrderDetails> findByOrderDetails(
			@PathVariable(value = "orderDetailsId") Integer orderDetailsId) throws OrderDetailsNotFoundException {
		OrderDetails orderdetails = orderDetailsService.findByOrderDetails(orderDetailsId)
				.orElseThrow(() -> new OrderDetailsNotFoundException(
						"No OrderDetails found with given addressId: " + orderDetailsId));
		return ResponseEntity.ok().body(orderdetails);
	}

	// Display messages assigned as per Validation Constraints
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();

		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));

		return errors;

	}

}
