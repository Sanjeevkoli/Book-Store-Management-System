package com.sprint.bookstore.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.bookstore.entities.User;
import com.sprint.bookstore.exception.UserNotFoundException;
import com.sprint.bookstore.repository.ILoginRepository;

@Service
public class LoginServiceImpl implements ILoginService {

	@Autowired
	ILoginRepository iLoginRepository;

	@Override
	public User addUser(User user) {
		return iLoginRepository.save(user);
	}

	@Override
	public User removeUser(User user) {
		iLoginRepository.delete(user);
		return user;
	}

	@Override
	public User validateUser(User user) throws UserNotFoundException {
		Optional<User> optionalUser = iLoginRepository.findById(user.getUserId());
		if (!optionalUser.isEmpty()) {
			if (optionalUser.get().getPassword().equals(user.getPassword())) {
				return user;
			} else {
				throw new UserNotFoundException("Wrong Password");
			}
		} else {
			throw new UserNotFoundException("User Not Found");
		}
	}

	@Override
	public String signOut(User user) throws UserNotFoundException {
		return "Signout successful";
	}
}
