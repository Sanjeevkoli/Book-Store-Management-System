package com.sprint.bookstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sprint.bookstore.entities.User;

@Repository
public interface ILoginRepository extends JpaRepository<User, Integer> {

}
