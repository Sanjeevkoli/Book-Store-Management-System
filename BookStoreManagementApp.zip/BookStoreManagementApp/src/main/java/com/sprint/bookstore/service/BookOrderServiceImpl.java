package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.bookstore.entities.BookOrder;
import com.sprint.bookstore.repository.IBookOrderRepository;

@Service
public class BookOrderServiceImpl implements IBookOrderService {

	@Autowired
	private IBookOrderRepository bookOrderRepository;

	@Override
	public BookOrder addOrder(BookOrder order) {
		return bookOrderRepository.save(order);
	}

	@Override
	public BookOrder updateOrder(BookOrder order) {
		return bookOrderRepository.save(order);
	}

	@Override
	public BookOrder removeOrder(BookOrder order) {
		bookOrderRepository.delete(order);
		return order;
	}

	@Override
	public List<BookOrder> viewAll() {
		return bookOrderRepository.findAll();
	}

	@Override
	public Optional<BookOrder> getOrderById(int orderId) {
		return bookOrderRepository.findById(orderId);
	}
}