package com.sprint.bookstore.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.bookstore.entities.Book;
import com.sprint.bookstore.exception.BookNotFoundException;
import com.sprint.bookstore.service.IBookService;

@RestController
@RequestMapping("/api")
public class BookController {
	@Autowired
	private IBookService bookService;

	// Inserts new Book in db
	@PostMapping("/Book/newBook")
	public Book createBook(@Validated @RequestBody Book book) {
		return bookService.createBook(book);
	}

	// Retrieves specific Book from db
	@GetMapping("/books/id/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable(value = "id") int bookId) throws BookNotFoundException {
		Book book = bookService.getBookById(bookId)
				.orElseThrow(() -> new BookNotFoundException("No Boook  found with this id: " + bookId));
		return ResponseEntity.ok().body(book);
	}

	// Retrieves all book from db
	@GetMapping("/Books/all")
	public List<Book> getAllBooks() {
		return bookService.listAllBooks();
	}

	// Updates existing Book details using provided Book id
	@PutMapping("/Book/update/{id}")
	public ResponseEntity<Book> updateBookById(@PathVariable(value = "id") Integer bookId,
			@Valid @RequestBody Book updBook) throws BookNotFoundException {
		Book book = bookService.getBookById(bookId)
				.orElseThrow(() -> new BookNotFoundException("No Book found with this id: " + bookId));
		book.setTitle(updBook.getTitle());
		book.setAuthor(updBook.getAuthor());
		book.setCategory(updBook.getCategory());
		book.setDescription(updBook.getDescription());
		book.setIsbn(updBook.getIsbn());
		book.setPrice(updBook.getPrice());
		book.setPublishDate(updBook.getPublishDate());
		book.setLastUpdatedOn(updBook.getLastUpdatedOn());

		// book.setEmailId(updBook.getEmailId());
		// book.setId(bookId);
		Book editedBook = bookService.editBook(book);
		return ResponseEntity.ok(editedBook);

	}

	// Deletes an Book record usingBook id
	@DeleteMapping("/Books/delete/{id}")
	public Map<String, Boolean> deleteBook(@PathVariable(value = "id") Integer bookId) throws BookNotFoundException {
		Book book = bookService.getBookById(bookId)
				.orElseThrow(() -> new BookNotFoundException("NoBook found with this id: " + bookId));
		bookService.deleteBook(book);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return response;
	}

	// Displays messages assigned as per Validation Constraints
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		// Key being the fieldname and message being the values/message associated
		Map<String, String> errors = new HashMap<>();

		// gets messages (assigned) for all individual fields
		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));

		return errors;

	}
}