package com.sprint.bookstore.service;

import com.sprint.bookstore.entities.User;
import com.sprint.bookstore.exception.UserNotFoundException;

public interface ILoginService {

	public User addUser(User user);

	public User removeUser(User user) throws UserNotFoundException;

	User validateUser(User user) throws UserNotFoundException;

	public String signOut(User user) throws UserNotFoundException;

}
