package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import com.sprint.bookstore.entities.Review;

public interface IReviewService {

	public List<Review> listAllReviews();

	public Review addReview(Review review);

	public Review deleteReview(Review review);

	public Review updateReview(Review review);

	public Optional<Review> getReviewById(Integer reviewId);

}
