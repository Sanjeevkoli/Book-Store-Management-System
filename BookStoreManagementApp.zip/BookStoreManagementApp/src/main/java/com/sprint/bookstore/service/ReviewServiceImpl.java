package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.bookstore.entities.Review;
import com.sprint.bookstore.repository.IReviewRepository;

@Service
public class ReviewServiceImpl implements IReviewService {

	@Autowired
	private IReviewRepository iReviewRepository;

	@Override
	public List<Review> listAllReviews() {

		return iReviewRepository.findAll();
	}

	@Override
	public Review addReview(Review review) {

		return iReviewRepository.save(review);
	}

	@Override
	public Review deleteReview(Review review) {
		iReviewRepository.delete(review);
		return review;
	}

	@Override
	public Review updateReview(Review review) {

		return iReviewRepository.save(review);
	}

	@Override
	public Optional<Review> getReviewById(Integer reviewId) {
		return iReviewRepository.findById(reviewId);
	}

}
