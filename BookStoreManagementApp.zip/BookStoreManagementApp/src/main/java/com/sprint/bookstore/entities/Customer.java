package com.sprint.bookstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "customer1")
public class Customer {

	@Id
	private int customerId; // primary
	@NotEmpty(message = "fullName Name is required")
	@Pattern(regexp = "^[a-zA-Z]*$", message = "Accepts Alphabets Only! Enter Valid Name")
	private String fullName;
	@OneToOne
	@JoinColumn(name = "addressId")
	private Address address;
	@NotEmpty(message = "mobileNumber Name is required")
	@Pattern(regexp = "^\\d{10}$", message = "Accepts Numbers Only! Enter Valid Number")
	private String mobileNumber;
	private String registerOn;

	public Customer() {
		super();
	}

	public Customer(int customerId, String fullName, Address address, String mobileNumber, String registerOn) {
		super();
		this.customerId = customerId;
		this.fullName = fullName;
		this.address = address;
		this.mobileNumber = mobileNumber;
		this.registerOn = registerOn;
	}

	@Column(name = "CustomerId", length = 10)

	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	@Column(name = "FullName", length = 10)
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Column(name = "MobileNumber", length = 10)
	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	@Column(name = "RegisterOn", length = 10)
	public String getRegisterOn() {
		return registerOn;
	}

	public void setRegisterOn(String registerOn) {
		this.registerOn = registerOn;
	}

	@Override
	public String toString() {
		return "Customer [ fullName=" + fullName + ", address=" + address + ", mobileNumber=" + mobileNumber
				+ ", registerOn=" + registerOn + "]";
	}
}
