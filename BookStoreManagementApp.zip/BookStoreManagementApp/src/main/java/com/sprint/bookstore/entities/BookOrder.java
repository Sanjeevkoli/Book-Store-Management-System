package com.sprint.bookstore.entities;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
public class BookOrder {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId; // primary
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "customerId")
	private Customer customer;
	@OneToMany(cascade = CascadeType.MERGE)
	@JoinColumn(name = "orderDetailsId")
	private Set<OrderDetails> orderDetails;
	private String orderDate;
	private float orderTotal;
	@NotEmpty(message = "status Name is required")
	private String status;
	@NotEmpty(message = "paymentMethod Name is required")
	private String paymentMethod;
	@NotEmpty(message = "recipientName Name is required")
	@Pattern(regexp = "^[a-zA-Z]*$", message = "Accepts Alphabets Only! Enter Valid Name")
	private String recipientName;
	@NotEmpty(message = "recipientPhone Name is required")
	@Pattern(regexp = "^\\d{10}$", message = "Accepts Numbers Only! Enter Valid Number")
	private String recipientPhone;

	public BookOrder() {
		super();
	}

	public BookOrder(int orderId, Customer customer, Set<OrderDetails> orderDetails, String orderDate, float orderTotal,
			String status, String paymentMethod, String recipientName, String recipientPhone) {
		super();
		this.orderId = orderId;
		this.customer = customer;
		this.orderDetails = orderDetails;
		this.orderDate = orderDate;
		this.orderTotal = orderTotal;
		this.status = status;
		this.paymentMethod = paymentMethod;
		this.recipientName = recipientName;
		this.recipientPhone = recipientPhone;
	}

	@Column(name = "OrderId", length = 10)
	
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Set<OrderDetails> getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(Set<OrderDetails> orderDetails) {
		this.orderDetails = orderDetails;
	}

	@Column(name = "OrderDate", length = 10)
	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	@Column(name = "OrderTotal", length = 10)
	public float getOrderTotal() {
		return orderTotal;
	}

	public void setOrderTotal(float orderTotal) {
		this.orderTotal = orderTotal;
	}

	@Column(name = "Status", length = 10)
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "PaymentMethod", length = 10)
	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	@Column(name = "RecipientName", length = 10)
	public String getRecipientName() {
		return recipientName;
	}

	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

	@Column(name = "RecipientPhone", length = 10)
	public String getRecipientPhone() {
		return recipientPhone;
	}

	public void setRecipientPhone(String recipientPhone) {
		this.recipientPhone = recipientPhone;
	}

	@Override
	public String toString() {
		return "BookOrder [orderId=" + orderId + ", customer=" + customer + ", orderDetails=" + orderDetails
				+ ", orderDate=" + orderDate + ", orderTotal=" + orderTotal + ", status=" + status + ", paymentMethod="
				+ paymentMethod + ", recipientName=" + recipientName + ", recipientPhone=" + recipientPhone + "]";
	}

}
