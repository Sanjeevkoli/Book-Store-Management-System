package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import com.sprint.bookstore.entities.Book;

public interface IBookService {

	public Book createBook(Book b);

	public List<Book> listAllBooks();

	public Optional<Book> getBookById(Integer bookId);

	public Book deleteBook(Book b);

	public Book editBook(Book b);

}