package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import com.sprint.bookstore.entities.Address;

public interface IAddressService {

	public Address addAddress(Address add);

	public Address updateAddress(Address add);

	public Address removeAddress(Address add);

	public List<Address> viewAllAddress();

	public Optional<Address> viewAddress(Integer addressId);

}
