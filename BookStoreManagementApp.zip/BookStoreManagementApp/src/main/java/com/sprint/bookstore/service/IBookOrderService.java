package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import com.sprint.bookstore.entities.BookOrder;

public interface IBookOrderService {
	public BookOrder addOrder(BookOrder order);

	public BookOrder updateOrder(BookOrder order);

	public BookOrder removeOrder(BookOrder order);

	public List<BookOrder> viewAll();

	Optional<BookOrder> getOrderById(int orderId);
}