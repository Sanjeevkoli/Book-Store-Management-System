package com.sprint.bookstore.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.bookstore.entities.BookOrder;
import com.sprint.bookstore.exception.BookOrderNotFoundException;
import com.sprint.bookstore.service.IBookOrderService;

@RestController
@RequestMapping("/api")
public class BookOrderController {

	@Autowired
	private IBookOrderService bookOrderService;

	// Adding address in database
	@PostMapping("/bookorder/newbookorder")
	public BookOrder addBookOrder(@Valid @RequestBody BookOrder bookOrder) {
		return bookOrderService.addOrder(bookOrder);
	}

	// Retrieves specific Bookorder from db
	@GetMapping("/bookorder/id/{id}")
	public ResponseEntity<BookOrder> getBookOrderById(@PathVariable(value = "id") int orderId)
			throws BookOrderNotFoundException {
		BookOrder bookOrder = bookOrderService.getOrderById(orderId)
				.orElseThrow(() -> new BookOrderNotFoundException("No Boook Order found with this id: " + orderId));
		return ResponseEntity.ok().body(bookOrder);
	}

	// Update Bookorder in database
	@PutMapping("/bookorder/update/{orderId}")
	public ResponseEntity<BookOrder> updateAddressById(@PathVariable(value = "orderId") Integer orderId,
			@RequestBody BookOrder updOrd) throws BookOrderNotFoundException {
		BookOrder bookOrder = bookOrderService.getOrderById(orderId)
				.orElseThrow(() -> new BookOrderNotFoundException("No book order found with gives orderId:" + orderId));
		bookOrder.setCustomer(updOrd.getCustomer());
		bookOrder.setOrderDetails(updOrd.getOrderDetails());
		bookOrder.setOrderDate(updOrd.getOrderDate());
		bookOrder.setOrderTotal(updOrd.getOrderTotal());
		bookOrder.setPaymentMethod(updOrd.getPaymentMethod());
		bookOrder.setRecipientName(updOrd.getRecipientName());
		bookOrder.setRecipientPhone(updOrd.getRecipientName());
		bookOrder.setStatus(updOrd.getStatus());

		BookOrder updatedBookOrder = bookOrderService.updateOrder(bookOrder);
		return ResponseEntity.ok(updatedBookOrder);

	}

	// Delete Bookorder by using Bookorder ID
	@DeleteMapping("/bookorder/delete/{addressId}")
	public ResponseEntity<BookOrder> removeAddress(@PathVariable("orderId") Integer orderId)
			throws BookOrderNotFoundException {
		BookOrder bookOrder = bookOrderService.getOrderById(orderId)
				.orElseThrow(() -> new BookOrderNotFoundException("Book Order not Found with this id: " + orderId));
		bookOrderService.removeOrder(bookOrder);

		return ResponseEntity.ok(null);
	}

	// View All Bookorders from database
	@GetMapping("/bookorder/viewall")
	public List<BookOrder> ViewAll() {
		return bookOrderService.viewAll();
	}

	// Display messages assigned as per Validation Constraints
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();

		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));

		return errors;

	}

}
