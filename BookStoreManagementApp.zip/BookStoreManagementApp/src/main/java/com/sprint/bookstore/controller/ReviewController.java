package com.sprint.bookstore.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.bookstore.entities.Address;
import com.sprint.bookstore.entities.Review;
import com.sprint.bookstore.exception.ReviewNotFoundException;
import com.sprint.bookstore.service.IReviewService;

@RestController
@RequestMapping("/api")
public class ReviewController {

	@Autowired
	private IReviewService ReviewService;

	// Adding review in database
	@PostMapping("/review/newreview")
	public Review addReview(@Valid @RequestBody Review review) {
		return ReviewService.addReview(review);
	}

	// Retrieves specific Review from db
	@GetMapping("/ Review/id/{id}")
	public ResponseEntity<Review> getReviewById(@PathVariable(value = "id") int reviewId)
			throws ReviewNotFoundException {
		Review review = ReviewService.getReviewById(reviewId)
				.orElseThrow(() -> new ReviewNotFoundException("NoReview  found with this id: " + reviewId));
		return ResponseEntity.ok().body(review);
	}

	// Retrieves allReview from db
	@GetMapping("/Review/all")
	public List<Review> getAllReview() {
		return ReviewService.listAllReviews();
	}

	// Deletes an Review record usingReview id
	@DeleteMapping("/Review/delete/{id}")
	public Map<String, Boolean> deleteReview(@PathVariable(value = "id") Integer ReviewId)
			throws ReviewNotFoundException {
		Review review = ReviewService.getReviewById(ReviewId)
				.orElseThrow(() -> new ReviewNotFoundException("NoReviewfound with this id: " + ReviewId));
		ReviewService.deleteReview(review);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return response;
	}

//Updates existing Review details using provided Review id
	@PutMapping("/Review/update/{id}")
	public ResponseEntity<Review> updateReviewById(@PathVariable(value = "id") Integer ReviewId,
			@Valid @RequestBody Review updReview) throws ReviewNotFoundException {
		Review review = ReviewService.getReviewById(ReviewId)
				.orElseThrow(() -> new ReviewNotFoundException("No Review found with this id: " + ReviewId));
		review.setBook(updReview.getBook());
		review.setCustomer(updReview.getCustomer());
		review.setHeadLine(updReview.getHeadLine());
		review.setComment(updReview.getComment());
		review.setRating(updReview.getRating());
		review.setReviewOn(updReview.getReviewOn());

		Review editedReview = ReviewService.updateReview(review);
		return ResponseEntity.ok(editedReview);
	}

//Displays messages assigned as per Validation Constraints
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		// Key being the fieldname and message being the values/message associated
		Map<String, String> errors = new HashMap<>();

		// gets messages (assigned) for all individual fields
		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));

		return errors;

	}

}