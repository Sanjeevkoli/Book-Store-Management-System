package com.sprint.bookstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "address1")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int addressId; // primary
	@NotEmpty(message = "Address Name is required")
	private String address;
	@NotEmpty(message = "City Name is required")
	@Pattern(regexp = "^[a-zA-Z]*$", message = "Accepts Alphabets Only! Enter Valid Name")
	private String city;
	@NotEmpty(message = "Country Name is required")
	@Pattern(regexp = "^[a-zA-Z]*$", message = "Accepts Alphabets Only! Enter Valid Name")
	private String country;
	@NotEmpty(message = "Pincode Name is required")
	@Pattern(regexp = "^\\d{6}$", message = "Accepts Numbers Only! Enter Valid Number")
	private String pincode;

	public Address() {
		super();
	}

	public Address(int addressId, String address, String city, String country, String pincode) {
		super();
		this.addressId = addressId;
		this.address = address;
		this.city = city;
		this.country = country;
		this.pincode = pincode;
	}

	@Column(name = "AddressId", length = 10)
	
	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	@JoinColumn(name = "addressId")
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "City", length = 30)
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "Country", length = 30)
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Column(name = "Pincode", length = 20)
	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", address=" + address + ", city=" + city + ", country=" + country
				+ ", pincode=" + pincode + "]";
	}

}
