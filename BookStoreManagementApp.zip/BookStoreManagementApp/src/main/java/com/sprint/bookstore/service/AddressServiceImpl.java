package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.bookstore.entities.Address;
import com.sprint.bookstore.repository.IAddressRepository;

@Service
public class AddressServiceImpl implements IAddressService {

	@Autowired
	private IAddressRepository addressRepository;

	// Add Address
	@Override
	public Address addAddress(Address add) {

		return addressRepository.save(add);
	}

	// Update Address
	@Override
	public Address updateAddress(Address add) {

		return addressRepository.save(add);
	}

	// Remove Address
	@Override
	public Address removeAddress(Address add) {
		addressRepository.delete(add);
		return add;

	}

	// View All Addresses
	@Override
	public List<Address> viewAllAddress() {
		return addressRepository.findAll();
	}

	// View Address by ID
	@Override
	public Optional<Address> viewAddress(Integer addressId) {
		return addressRepository.findById(addressId);

	}
}
