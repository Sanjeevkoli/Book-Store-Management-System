package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.bookstore.entities.Category;
import com.sprint.bookstore.repository.ICategoryRepository;

@Service
public class CategoryServiceImpl implements ICategoryService{
	
	@Autowired
	private ICategoryRepository iCategoryRepository;

	@Override
	public Category addCategory(Category cat) {
		return iCategoryRepository.save(cat);
	}

	@Override
	public Category editCategory(Category cat) {
		return iCategoryRepository.save(cat);
	}

	@Override
	public List<Category> viewAllCategories() {
		//Optional<Category>category1 = iCategoryRepository.findById(cat.getCategoryId());
		//return category1.get();
		return iCategoryRepository.findAll();
	}

	@Override
	public Category removeCategory(Category cat) {
		iCategoryRepository.delete(cat);
		return cat;
	}
	@Override
	public Optional<Category> getCategoryById(Integer categoryId) {
		// TODO Auto-generated method stub
		return iCategoryRepository.findById(categoryId);
	}

}