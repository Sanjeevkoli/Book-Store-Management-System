package com.sprint.bookstore.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sprint.bookstore.entities.User;
import com.sprint.bookstore.exception.UserNotFoundException;
import com.sprint.bookstore.service.ILoginService;

@RestController
@RequestMapping("/api")
public class LoginController {

	@Autowired
	private ILoginService service;

	@PostMapping("/add")
	public User addUser(@Valid @RequestBody User user) {
		return service.addUser(user);
	}

	@DeleteMapping("/remove/{userId}")
	public User removeUser(@PathVariable("userId") User user) throws UserNotFoundException {
		return service.removeUser(user);
	}

	@PostMapping("/login")
	public ResponseEntity<User> validateUser(@RequestBody User user) throws UserNotFoundException {
		User user1 = service.validateUser(user);
		return new ResponseEntity<User>(user1, HttpStatus.OK);
	}

	@GetMapping("/user/signout")
	public String signOut(User user) throws UserNotFoundException {
		return service.signOut(user);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();

		ex.getBindingResult().getFieldErrors()
				.forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));

		return errors;
	}

}
