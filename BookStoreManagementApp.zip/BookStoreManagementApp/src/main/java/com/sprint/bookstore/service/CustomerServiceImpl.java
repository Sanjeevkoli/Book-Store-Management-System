package com.sprint.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sprint.bookstore.entities.Customer;
import com.sprint.bookstore.repository.ICustomerRepository;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	private ICustomerRepository iCustomerRepository;

	@Override
	public Customer createCustomer(Customer c) {
		return iCustomerRepository.save(c);
	}

	@Override
	public List<Customer> listCustomers() {
		return iCustomerRepository.findAll();
	}

	@Override
	public Customer deleteCustomer(Customer c) {
		iCustomerRepository.delete(c);
		return c;
	}

	@Override
	public Customer updateCustomer(Customer c) {
		return iCustomerRepository.save(c);
	}

	@Override
	public Optional<Customer> viewCustomer(Integer customerId) {

		return iCustomerRepository.findById(customerId);
	}

	@Override
	public Optional<Customer> getCustomerById(Integer id) {

		return iCustomerRepository.findById(id);
	}
}
