package com.sprint.bookstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sprint.bookstore.entities.BookOrder;

public interface IBookOrderRepository extends JpaRepository<BookOrder, Integer> {

}
