package com.sprint.bookstore.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
public class OrderDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderDetailsId; // primary
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "bookId")
	private Book book;

	private int quantity;

	private float subtotal;

	public OrderDetails() {
		super();
	}

	public OrderDetails(int orderDetailsId, Book book, BookOrder bookOrder, int quantity, float subtotal) {
		super();
		this.orderDetailsId = orderDetailsId;
		this.book = book;
		this.quantity = quantity;
		this.subtotal = subtotal;
	}

	@Column(name = "OrderDetailsId", length = 10)
	public int getOrderDetailsId() {
		return orderDetailsId;
	}

	public void setOrderDetailsId(int orderDetailsId) {
		this.orderDetailsId = orderDetailsId;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	@Column(name = "Quantity", length = 10)
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Column(name = "Subtotal", length = 10)
	public float getSubtotal() {
		return subtotal;
	}

	public void setSubtotal(float subtotal) {
		this.subtotal = subtotal;
	}

	@Override
	public String toString() {
		return "OrderDetails [book=" + book + ", bookOrder=" + ", quantity=" + quantity + ", subtotal=" + subtotal
				+ "]";
	}

}
